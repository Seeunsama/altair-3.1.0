# flake8: noqa
from .core import *

SCHEMA_VERSION = 'v5.4.0'
SCHEMA_URL = 'https://vega.github.io/schema/vega/v5.4.0.json'

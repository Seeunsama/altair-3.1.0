# flake8: noqa
from .core import *
from .channels import *
SCHEMA_VERSION = 'v2.6.0'
SCHEMA_URL = 'https://vega.github.io/schema/vega-lite/v2.6.0.json'

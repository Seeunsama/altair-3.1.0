"""Altair schema wrappers"""
# flake8: noqa
from .v2.schema import *

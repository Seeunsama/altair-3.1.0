D3_JS_URL = "https://d3js.org/d3.v3.min.js"
VEGA_JS_URL = "https://cdnjs.cloudflare.com/ajax/libs/vega/2.6.5/vega.min.js"
VEGALITE_JS_URL = "https://cdnjs.cloudflare.com/ajax/libs/vega-lite/1.2.1/vega-lite.min.js"
VEGAEMBED_JS_URL = "https://cdnjs.cloudflare.com/ajax/libs/vega-embed/2.2.0/vega-embed.min.js"
